#include "common_log.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_mac.h"
#include <cstring>
#include <cstdio>

#define TAG "UTILS"


void corrupt_partition(const esp_partition_t *partition) {
   uint8_t dummy_data[4] = {0xFF, 0xFF, 0xFF, 0xFF}; // Overwrite the magic byte 0xE9
   // A small write to offset 0 will make the partition unbootable by the ESP32 bootloader
   if (esp_partition_write(partition, 0, dummy_data, sizeof(dummy_data)) != ESP_OK) {
       INFO("Failed to corrupt partition header!");
   } else {
       INFO("Partition header corrupted successfully.");
   }
}

void print_hash(const char *prefix, const uint8_t *hash) {
    printf(prefix);
    for(int i=0; i<32; i++) printf("%02x", hash[i]);
    printf("\r\n");
}   
    
char *getDeviceName() {
    static char name[20];
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(name, sizeof(name), "Meshtastic_%02X%02X", mac[4], mac[5]);
    return name;
}